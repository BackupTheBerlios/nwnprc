A TGA image reader plugin for ImageIO.  This software is made available
under the LGPL license.

  This reader supports 15, 16, 24, and 32 bit compressed (RLE) or uncompressed
  targa images.  Monochrome or color mapped images are not supported.  Refer
  to com.realityinteractive.imageio.tga.TGAImageReader for more information.

To use:

  Place the imageio_tga_X.Y.Z.jar file into the classpath of the application
  that requires the support.  

  That's it.  ImageIO will register any plugin that it finds in the classpath.

Do's and Don'ts:

o  Use ImageIO.read() rather than ImageReader.readXXX() as only the 
   default ImageReadParam's are supported.  See:

       test-java/com/realityinteractive/imageio/ImageLoader.java

   for more information.

o  Call:

     ImageIO.setUseCache(false);

   By default ImageIO will use a file-based cache to support marks and seeks.
   Performance will be intolerable if the file-based cache is used.


Refer to the RELEASE_NOTES for more information about the current release.

Last Update v1.0.0