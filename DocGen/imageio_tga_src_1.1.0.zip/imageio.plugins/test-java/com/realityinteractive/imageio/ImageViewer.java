package com.realityinteractive.imageio;

/*
 * ImageViewer.java
 * Copyright (c) 2003 Reality Interactive, Inc.  
 *   See bottom of file for license and warranty information.
 * Created on Sep 27, 2003
 */

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.MediaTracker;
import java.awt.RenderingHints;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;

import javax.swing.JApplet;
import javax.swing.JFrame;

/**
 * <p>A {@link java.awt.image.BufferedImage} viewer.</p>
 * 
 * @author Rob Grzywinski <a href="mailto:rgrzywinski@realityinteractive.com">rgrzywinski@realityinteractive.com</a>
 * @version $Id: //src/other/imageio.plugins/test-java/com/realityinteractive/imageio/ImageViewer.java#2 $
 * @since 1.0
 */
// NOTE:  this is essentially a testing ground for images and should be 
//        relatively the same as Texture2DFactory
public class ImageViewer extends JApplet
{
    /**
     * <p>The {@link java.awt.image.BufferedImage} to be draw.  This may be
     * <code>null</code>.</p>
     */
    private BufferedImage image;

    // =========================================================================
    /**
     * <p>Sets the {@link java.awt.image.BufferedImage} to be displayed. A
     * {@link java.awt.MediaTracker} to ensure that the image is loaded. </p>
     * 
     * @param  image the <code>BufferedImage</code> to be displayed
     */
    public void setImage(final BufferedImage image)
    {
        // ensure that the image is not null
        if(image == null)
            throw new IllegalArgumentException("The image cannot be null.");
        /* else -- the image is not null */

        // set the image
        this.image = image;

        // wait until the image is loaded
        final MediaTracker tracker = new MediaTracker(this);
        tracker.addImage(image, 0);
        try
        {
            tracker.waitForID(0);
        } catch(InterruptedException ie)
        {
            // TODO Auto-generated catch block
            ie.printStackTrace();
        }
    }

    /**
     * <p>Set the background to black and draw the {@link java.awt.image.BufferedImage}
     * if there is one.</p>
     * 
     * @see java.awt.Component#paint(java.awt.Graphics)
     */
    public void paint(final Graphics graphics)
    {
        // get the Java2D graphics context
        final Graphics2D graphics2D = (Graphics2D)graphics;

        // set the background color.  Black is used so that an alpha channel
        // in the image is more appearant
        graphics2D.setBackground(Color.BLACK);

        // clear the area and set the rendering hints
        final Dimension dimensions = getSize();
        graphics2D.clearRect(0, 0, dimensions.width, dimensions.height);
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING,
                                    RenderingHints.VALUE_RENDER_QUALITY);

        // draw the image (if there is one)
        if(image != null)
            graphics2D.drawImage(image, 0, 0, this);
        /* else -- setImage() was never called */
    }
    
    // =========================================================================
    /**
     * <p>Load and display a image via a hardcoded name.</p> 
     */
    public static void main(final String[] args)
    {
        // load an image
        final BufferedImage image;
        try
        {
            // *** Set the Image Name here ***
            image = ImageLoader.loadImage("testC32.tga");
        } catch(ImageException te)
        {
            te.printStackTrace();
            return;
        }

        // construct the ImageViewer
        final ImageViewer imageViewer = new ImageViewer();

        // initialize (just fulfilling the Applet contract)
        imageViewer.init();

        // set the image to be viewed
        imageViewer.setImage(image);

        // create and display a window to validate the loaded image
        final JFrame frame = new JFrame("BufferedImage Viewer");
        frame.addWindowListener(new WindowAdapter()
        {
            /**
             * <p>Exit the application when closing the window.</p>
             * 
             * @see java.awt.event.WindowListener#windowClosing(java.awt.event.WindowEvent)
             */
            public void windowClosing(final WindowEvent windowEvent)
            {   
                System.exit(0);
            }
        });
        frame.getContentPane().add("Center", imageViewer);
        frame.pack();
        frame.setSize(new Dimension(800, 600));
        frame.show();
    }
}
// =============================================================================
/*
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */