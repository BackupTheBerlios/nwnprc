/*
 *  TLKTools - TLK<->XML generation tools
 *  functions.c
 *
 *  Copyright (C) 2004-2005 Guido Imperiale
 *  This code is released under the terms of the GNU GPL.
 *  Please refer to tlktools.h for more info.
 */

#include "tlktools.h"


//global variables
entry * db = NULL;
DWORD StringCount = 0;
int BigEndian;



int IsBigEndian() {
	DWORD x = 1;
	char * b = (char *)&x;
	return (b[0] == 0);
}


DWORD SwapEndian (DWORD x)
{
	char * b = (char *)&x;
	char tmp = b[0];
	b[0] = b[3];
	b[3] = tmp;
	tmp = b[1];
	b[1] = b[2];
	b[2] = tmp;

	return x;
}



DWORD db_insert(DWORD StrRef, DWORD lang, char sex, DWORD StringSize, const char * data, int quiet, int find_first_free)
{
	//current pointer in the database, static for performance
	static entry * dbp = NULL;

	StrRef &= 0x00FFFFFF;	//mask out the alternate table bit

	//no entry
	if (StringSize == 0)
		return StrRef;

	//move the cursor to the proper entry
	//if find_first_free is true, move until we find a completely empty entry
	while (dbp != NULL)
	{
		if (dbp->StrRef == StrRef) {
			if (find_first_free)
				StrRef++;
			else
				break;
		}
				
		if (dbp->StrRef < StrRef) {
			if (dbp->right == NULL || dbp->right->StrRef > StrRef)
				break;
			else
				dbp = dbp->right;
		} else {
			dbp = dbp->left;		//eventually NULL
		}
	}

	//case 1: dbp == NULL				first entry (but others may already be in place)
	//case 2: dbp->StrRef == StrRef		update existing entry
	//case 3: else						attach new entry to dbp_right

	if (dbp == NULL || dbp->StrRef != StrRef) {
		//case 1 and 3, create new entry

		//allocate RAM and reset content
		entry * new_entry = calloc(1, sizeof(entry));

		if (new_entry == NULL) {
			fprintf(stderr, "ERROR: RAM full!!\n");
			exit(1);
		}

		if (dbp == NULL) {
			if (db != NULL) {
				db->left = new_entry;
				new_entry->right = db;
			}
			db = new_entry;
		} else {
			new_entry->left = dbp;
			new_entry->right = dbp->right;
			dbp->right = new_entry;
			if (new_entry->right != NULL)
				new_entry->right->left = new_entry;
		}

		dbp = new_entry;
		dbp->StrRef = StrRef;

		if (StrRef+1 > StringCount)
			StringCount = StrRef+1;
	}

	//insert data

	if (lang > 127)
		lang -= 122;	//korean & c.: 128-->6, 131-->9

	if (lang > 9) {
		fprintf(stderr, "ERROR: invalid language\n");
		exit(1);
	}

	if (sex == 'm') {
		if (dbp->m[lang].data != NULL) {
			if (!quiet && strcmp(dbp->m[lang].data, data) != 0)
				fprintf(stderr, "WARNING: overwriting entry %u with a different value\n", (unsigned int)StrRef);
			free(dbp->m[lang].data);
		}
		dbp->m[lang].len = StringSize;
		dbp->m[lang].data = (char *)data;
	} else {
		if (dbp->f[lang].data != NULL) {
			if (!quiet && strcmp(dbp->f[lang].data, data) != 0)
				fprintf(stderr, "WARNING: overwriting entry %u with a different value\n", (unsigned int)StrRef);
			free(dbp->f[lang].data);
		}
		dbp->f[lang].len = StringSize;
		dbp->f[lang].data = (char *)data;
	}
	
	return StrRef;
}


char * xml_encode(const char * string) {
	static char buf[65536];

	char * tmp = charset_toUTF8(string, "ISO-8859-1");
	//convert input string to UTF-8 from ISO-8859-1

	int p=0, q=0;

	for (p=0, q=0; tmp[p] != '\0'; p++, q++) {
		if (q > 65535) {
			fprintf(stderr, "ERROR: buffer overflow in eamp_encode()\n");
			exit(1);
		}

		buf[q] = tmp[p];
		if (buf[q] == '&') {
			buf[++q] = 'a';
			buf[++q] = 'm';
			buf[++q] = 'p';
			buf[++q] = ';';
		}
	}

	buf[q] = '\0';

	free(tmp);
	return buf;
}


DWORD GetLangID(const char * slang) {
	if      (strcasecmp(slang, "en") == 0) return 0;
	else if (strcasecmp(slang, "fr") == 0) return 1;
	else if (strcasecmp(slang, "de") == 0) return 2;
	else if (strcasecmp(slang, "it") == 0) return 3;
	else if (strcasecmp(slang, "sp") == 0) return 4;
	else if (strcasecmp(slang, "po") == 0) return 5;
	else if (strcasecmp(slang, "ko") == 0) return 128;
	else if (strcasecmp(slang, "ct") == 0) return 129;
	else if (strcasecmp(slang, "cs") == 0) return 130;
	else if (strcasecmp(slang, "jp") == 0) return 131;
	else {
		fprintf(stderr, "ERROR: unknown language: %s\n", slang);
		exit(1);
	}
}


char * charset_toUTF8 (const char * in, const char * encoding)
{
	unsigned char * out;
    int ret, size, out_size, temp;
    xmlCharEncodingHandlerPtr handler;

    size = strlen(in) + 1;
    out_size = size * 2 - 1;
    out = malloc(out_size);

    if (out == NULL) {
		fprintf(stderr, "ERROR: Out of memory!\n");
		exit(1);
	}

	handler = xmlFindCharEncodingHandler(encoding);
    if (handler == NULL) {
    	free(out);
        out = NULL;
	} else {
		temp = size - 1;
        ret = handler->input(out, &out_size, in, &temp);
        if (ret < 0) {
			printf("ERROR: charset_toUTF8: conversion failed (");
	        switch(ret) {
				case -1:
					printf("lack of space):\n%s\n", in);
					break;
				case -2:
					printf("transcoding failed):\n%s\n", in);
					break;
				default:
					printf("unknown error - %d bytes written):\n%s\n", ret, in);
					break;
			}
			exit(1);
        } else {
    		out = realloc(out, out_size + 1);
			out[out_size] = '\0'; /*null terminating out*/
        }
	}

	return (out);
}


char * charset_fromUTF8 (const char * in, const char * encoding)
{
	unsigned char * out;
    int ret, size, out_size, temp;
    xmlCharEncodingHandlerPtr handler;

    size = strlen(in) + 1;
    out_size = size * 2 - 1;
    out = malloc(out_size);

    if (out == NULL) {
		fprintf(stderr, "ERROR: Out of memory!\n");
		exit(1);
	}

	handler = xmlFindCharEncodingHandler(encoding);
    if (handler == NULL) {
    	free(out);
        out = NULL;
	} else {
		temp = size - 1;
        ret = handler->output(out, &out_size, in, &temp);
        if (ret < 0) {
			printf("ERROR: charset_fromUTF8: conversion failed (");
	        switch(ret) {
				case -1:
					printf("lack of space):\n%s\n", in);
					break;
				case -2:
					printf("transcoding failed):\n%s\n", in);
					break;
				default:
					printf("unknown error - %d bytes written):\n%s\n", ret, in);
					break;
			}
			exit(1);
        } else {
    		out = realloc(out, out_size + 1);
			out[out_size] = '\0'; /*null terminating out*/
        }
	}

	return (out);
}
