/*
 *  TLKTools - TLK<->XML generation tools
 *  gff.c
 *
 *  Copyright (C) 2004-2005 Guido Imperiale
 *  This code is released under the terms of the GNU GPL.
 *  Please refer to tlktools.h for more info.
 */

#include "tlktools.h"


static const char gff_extensions[][9] = {
	".are.xml",
	".dlg.xml",
	".fac.xml",
	".gic.xml",
	".git.xml",
	".ifo.xml",
	".itp.xml",
	".jrl.xml",
	".utc.xml",
	".utd.xml",
	".ute.xml",
	".uti.xml",
	".utm.xml",
	".utp.xml",
	".uts.xml",
	".utt.xml",
	".utw.xml",
	"\0\0\0"
};	



//return the StringRef of the current node, or -1 if none is specified, or -2 if current node isn't a LocString
int xml_fetch_StringRef(xmlNode * node)
{
	assert(node);

	if (node->type != XML_ELEMENT_NODE || strcasecmp(node->name, "Field") != 0)
		return -2;
		 
	//test type
	xmlChar * sType = xmlGetProp(node, "Type");
	if (sType == NULL || strcasecmp(sType, "LocString") != 0) {
		xmlFree(sType);
		return -2;
	}
	xmlFree(sType);
	
	xmlChar * sStrRef = xmlGetProp(node, "StringRef");
	int nRes = atoi(sStrRef);
	xmlFree(sStrRef);
	return nRes;
}


//match a single element of the gff_list and eventually process.
//return 1 if the element has been processed; 0 otherwise.
int match_list_element(
	grl_element * list_element,
	xmlNode * node, 
	int Appearance_Type, 
	int Gender, 
	int Phenotype, 
	char * Tileset, 
	int BaseItem)
{
	assert(list_element);
	assert(node);
	
	//TODO
	
	return 0;
	
}


//recursively process a GFF (in XML format)
//return the new offset
int gffparse(
	xmlNode * a_node,
	int offset,
	int extract,
	const gff_rules_list * list,
	int Appearance_Type,
	int Gender,
	int Phenotype,
	char * Tileset,
    int BaseItem)
{
	if (offset == 0)	//BAD STRREF - start at 1 instead
		offset++;
		
    xmlNode * cur_node = NULL;

    for (cur_node = a_node; cur_node != NULL; cur_node = cur_node->next)
	{
		int nStrRef = xml_fetch_StringRef(cur_node);
		int substrings_count = 0;
		
		//it's a LocString; extract it
		if (nStrRef != -2 && extract) 
		{
			xmlNode * SubString_node;
			for (SubString_node = cur_node->children; SubString_node != NULL; SubString_node = SubString_node->next) 
			{
				if (SubString_node->type != XML_ELEMENT_NODE || strcasecmp(SubString_node->name, "SubString") != 0)
					continue;
				
				substrings_count++;

				if (!extract)
					break;		//skip LocStrings with custom content
					
				xmlChar * StringId = xmlGetProp(SubString_node, "StringId");
				if (StringId == NULL) {
					fprintf(stderr, "Error: Malformed GFF: no StringId in SubString\n");
					return offset;
				}
				int lang_code = atoi(StringId);
				xmlFree(StringId);
				
				//FIXME: untested
				DWORD lang = lang_code / 2;
				char sex = (lang_code % 2 == 0 ? 'm' : 'f');

				xmlChar * sValue = xmlGetProp(SubString_node, "Value");
				if (sValue == NULL) {
					fprintf(stderr, "Error: Malformed GFF: no Value in SubString\n");
					return offset;
				}
				
				char * data = charset_fromUTF8(sValue, "ISO-8859-1");
				
				//fprintf(stderr, "%s\n", data);
				//TODO clean up from tags
				
				int StringSize = strlen(data);
				xmlFree(sValue);

				if (substrings_count == 1)
					offset = (int)db_insert((DWORD)offset, lang, sex, StringSize, data, 0, 1);
				else
					db_insert((DWORD)offset, lang, sex, StringSize, data, 0, 0);
				
				//TODO: eliminate substring
			}
			
			if (substrings_count > 0)
			{
				nStrRef = offset;
				
				//TODO: update StrRef
			}
		}
		
		else
		{
			if (list != NULL && cur_node->type == XML_ELEMENT_NODE)
			{
				//all other nodes: parse them
			
				//TODO: fetch Appearance_Type etc.
				
				int i;
				for (i = 0; i < list->len; i++) 
				{
					if (match_list_element(&list->list[i], cur_node, Appearance_Type, Gender, Phenotype, Tileset, BaseItem) != 0)
						break;
				}
			}

			offset = gffparse(cur_node->children, offset, extract, list, Appearance_Type, Gender, Phenotype, Tileset, BaseItem);

		}
	}
	
	return offset;
}


//parse a single GFF file
//return the new offset
int gffprocess(const char * fname, int offset, int extract, const gff_rules_list * list)
{
	assert(fname);
	
	//extension check
	char ext[9];
	int i;
	int fname_len = strlen(fname);
	if (fname_len < 9)
		return offset;
	for (i = 0; i < 9; i++)
		ext[i] = tolower(fname[fname_len - 8 + i]);
		
	for (i = 0; gff_extensions[i][0] != '\0'; i++) {
		if (strcmp(gff_extensions[i], ext) == 0)
			break;
	}
	if (gff_extensions[i][0] == '\0')
		return offset;	//silently skip invalid files

	fprintf(stderr, "Parsing GFF file: %s\n", fname);

    xmlDocPtr doc = NULL;
	xmlNodePtr root_element = NULL;

	doc = xmlReadFile(fname, NULL, 0);

    if (doc == NULL) {
        fprintf(stderr, "ERROR: could not parse file %s\n", fname);
		return offset;
    }

    //Get the root element node
    root_element = xmlDocGetRootElement(doc);

	//Process it
    offset = gffparse(root_element, offset, extract, list, -1, -1, -1, NULL, -1);

	//Save the file
	xmlSaveFormatFileEnc(fname, doc, "ISO-8859-1", 1);

    //Free the document
    xmlFreeDoc(doc);
	
	return offset;
}



//add a rule to a gff_rules_list
gff_rules_list * gff_rules_list_add(gff_rules_list * list, xmlNode * rule)
{
	/*  just a linear array. Surely not the fastest algoritm ever, 
	 *  but after all we're dealing with -at most- a few hundreds
	 *  hand-written operations, so why worry?
	 */
	
	if (list == NULL) {
		list = calloc(1, sizeof(gff_rules_list));
		assert(list);
	}
	
	if (list->len % GFFRULESLIST_SEGMENT == 0) {
		list->list = realloc(list->list, sizeof(grl_element) * (list->len + GFFRULESLIST_SEGMENT));
		assert(list->list);
	}
	
	
	//TODO: parse node
	
	list->len++;

	return list;
}


//free a gff_rules_list
void gff_rules_list_free(gff_rules_list * list)
{
	if (list != NULL) {
		int i;
		for (i = 0; i < list->len; i++) 
		{
			xmlFree(list->list[i].Label_Name);
			xmlFree(list->list[i].Label     );
			xmlFree(list->list[i].Property  );
			xmlFree(list->list[i].Tileset   );
			xmlFree(list->list[i].from      );
			xmlFree(list->list[i].to        );
		}
		free(list->list);
		free(list);
	}
}
