/*
 *  TLKTools - TLK<->XML generation tools
 *  tlkrw.c
 *
 *  Copyright (C) 2004-2005 Guido Imperiale
 *  This code is released under the terms of the GNU GPL.
 *  Please refer to tlktools.h for more info.
 */

#include "tlktools.h"


//load the talk table from a TLK file
void tlkread(const char * fname, int offset, char sex, int quiet)
{
	TLKHeader head;
	StringData3 data;
	int StrRef;
	char * strdata = NULL;

	FILE * fp = fopen(fname, "rb");

	if (fp == NULL) {
		fprintf(stderr, "%s: file not found.\n", fname);
		exit(1);
	}

	fread(&head, sizeof(head), 1, fp);

	if (BigEndian) {
		head.LanguageID          = SwapEndian(head.LanguageID         );
		head.StringCount         = SwapEndian(head.StringCount        );
		head.StringEntriesOffset = SwapEndian(head.StringEntriesOffset);
	}

	if (memcmp(head.Signature, "TLK V3.0", 8) != 0)
		fprintf(stderr, "WARNING: invalid or malformed TLK header: %s\n", fname);

	for (StrRef = 0; StrRef < head.StringCount; StrRef++) {
		fread(&data, sizeof(data), 1, fp);

		if (BigEndian) {
			data.Flags          = SwapEndian(data.Flags         );
			data.OffsetToString = SwapEndian(data.OffsetToString);
			data.StringSize     = SwapEndian(data.StringSize    );
		}

		if ((data.Flags & TEXT_PRESENT) == 0 || data.StringSize == 0)
			continue;

		strdata = malloc(data.StringSize + 1);
		if (strdata == NULL) {
			fprintf(stderr, "ERROR: RAM full!!\n");
			exit(1);
		}

		// Of course it would be faster to read it sequentially.
		// But it would also be a pain in the ass and definitely not worh the effort.
		long pos = ftell(fp);
		fseek(fp, head.StringEntriesOffset + data.OffsetToString, SEEK_SET);
		fread(strdata, data.StringSize, 1, fp);
		strdata[data.StringSize] = '\0';
		fseek(fp, pos, SEEK_SET);

		db_insert(StrRef + offset, head.LanguageID, sex, data.StringSize, strdata, quiet, 0);
	}

	fclose(fp);

}


//write the talk table to a TLK file
void tlkwrite(const char * fname, DWORD lang, char sex)
{
	TLKHeader head;
	StringData3 data;
	int StrRef;
	DWORD text_pointer = 0;

	FILE * fp = fopen(fname, "wb");

	if (fp == NULL) {
		fprintf(stderr, "%s: could not open file.\n", fname);
		exit(1);
	}

	//write Header
	memcpy(&head.Signature, "TLK V3.0", 8);
	head.LanguageID = lang;
	head.StringCount = StringCount;
	head.StringEntriesOffset = sizeof(TLKHeader) + StringCount * sizeof(StringData3);

	if (BigEndian) {
		head.LanguageID          = SwapEndian(head.LanguageID         );
		head.StringCount         = SwapEndian(head.StringCount        );
		head.StringEntriesOffset = SwapEndian(head.StringEntriesOffset);
	}

	fwrite(&head, sizeof(head), 1, fp);

	if (lang > 127)
		lang -= 122;	//eastern languages: 128-->6, 131-->9

	if (lang > 9) {
		fprintf(stderr, "ERROR: invalid language\n");
		exit(1);
	}


	entry * dbp;
	memset(&data, 0, sizeof(data));

	//write StringData Table
	for (dbp = db, StrRef = 0; StrRef < StringCount; StrRef++)
	{
		if (dbp == NULL) {
			fprintf(stderr, "ERROR: wrong number of strings in database!\n");
			exit(1);
		}

		if (dbp->StrRef > StrRef) {
			//write an empy string
			data.Flags = 0;
			data.StringSize = 0;
			data.OffsetToString = 0;
		} else if (dbp->StrRef < StrRef) {
			fprintf(stderr, "WTF? dbp->StrRef < StrRef\n");
			exit(1);
		} else {
			if (sex == 'm' || (sex == 'f' && dbp->f[lang].len == 0)) {
				if (dbp->m[lang].len != 0) {
					data.Flags = TEXT_PRESENT;
					data.StringSize = dbp->m[lang].len;
					data.OffsetToString = text_pointer;
				} else if (dbp->m[0].len != 0) {
					//default to english
					data.Flags = TEXT_PRESENT;
					data.StringSize = dbp->m[0].len;
					data.OffsetToString = text_pointer;
				} else {
					//no string
					data.Flags = 0;
					data.StringSize = 0;
					data.OffsetToString = 0;
				}
			} else {
				//female
				data.Flags = TEXT_PRESENT;
				data.StringSize = dbp->f[lang].len;
				data.OffsetToString = text_pointer;
			}

			text_pointer += data.StringSize;
			dbp = dbp->right;

			if (BigEndian) {
				data.Flags          = SwapEndian(data.Flags         );
				data.OffsetToString = SwapEndian(data.OffsetToString);
				data.StringSize     = SwapEndian(data.StringSize    );
			}
		}

		fwrite(&data, sizeof(data), 1, fp);

	}


	//write StringEntry table
	for (dbp = db; dbp != NULL; dbp = dbp->right)
	{
		if (sex == 'm' || (sex == 'f' && dbp->f[lang].len == 0)) {
			if (dbp->m[lang].len > 0) {
				fwrite(dbp->m[lang].data, dbp->m[lang].len, 1, fp);
			} else if (dbp->m[0].len != 0) {
				//default to enlglish
				fwrite(dbp->m[0].data, dbp->m[0].len, 1, fp);
			}
		} else {
			//female
			fwrite(dbp->f[lang].data, dbp->f[lang].len, 1, fp);
		}
	}

	fclose(fp);
}
