/*
 *  TLKTools - TLK<->XML generation tools
 *  tlktools.c
 *
 *  Copyright (C) 2004-2005 Guido Imperiale
 *  This code is released under the terms of the GNU GPL.
 *  Please refer to tlktools.h for more info.
 */

#include "tlktools.h"


int main(int argc, char ** argv)
{
    // initialize libxml2 and check potential ABI mismatches between
	// the version it was compiled for and the actual shared library used.
    LIBXML_TEST_VERSION

	//initialize BigEndian <-> LittleEndian conversion
	BigEndian = IsBigEndian();
	if (BigEndian)
		fprintf(stderr, "WARNING: operations on a BigEndian systems are totally UNTESTED.\n");

	if (argc != 2) {
		fprintf(stderr, "Usage: tlktools command.xml\n");
		exit(1);
	}

	xmlread(argv[1], 0, 0, 'm', 0);

    xmlCleanupParser();
    xmlMemoryDump();

	return 0;
}
