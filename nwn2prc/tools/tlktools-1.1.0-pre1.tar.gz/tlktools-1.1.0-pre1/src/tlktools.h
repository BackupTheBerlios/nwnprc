/*
    TLKTools - TLK<->XML generation tools
    tlktools.h

    Copyright (C) 2004-2005 Guido Imperiale

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

       Guido Imperiale
    crusaderky@libero.it
    ---------------------
         CRVSADER/KY
    CVI.SCIENTIA.IMPERIVM
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <assert.h>
#include <libxml/parser.h>
#include <libxml/tree.h>


//Bioware specifications
typedef unsigned short WORD;
typedef unsigned int   DWORD;

typedef struct TLKHeader {
	char  Signature[8];		//"TLK V3.0", without the leading \0
	DWORD LanguageID;
	DWORD StringCount;
	DWORD StringEntriesOffset;
} TLKHeader;

//version 3.0 with SNDLENGTH_PRESENT
typedef struct StringData3 {
	DWORD Flags;
	char  SoundResRef[16];
	DWORD VolumeVariance;
	DWORD PitchVariance;
	DWORD OffsetToString;
	DWORD StringSize;
	float SoundLength;
} StringData3;


//version <3.0 or without SNDLENGTH_PRESENT
typedef struct StringData2 {
	DWORD Flags;
	char  SoundResRef[16];
	DWORD VolumeVariance;
	DWORD PitchVariance;
	DWORD OffsetToString;
	DWORD StringSize;
} StringData2;


//internal string entry
typedef struct string {
	DWORD len;
	char * data;	//NULL terminated
} string;


//internal database entry
//NOT using balanced trees since 99% of the work will be sequential
typedef struct entry {
	struct entry * left;
	struct entry * right;
	DWORD StrRef;
	string m[10], f[10];
} entry;


#define GFFRULE_FIND    1
#define GFFRULE_REPLACE 2
#define GFFRULE_SWAP    3

//number of elements per rules list segment
#define GFFRULESLIST_SEGMENT 512

//internal gff_rules_list element
typedef struct {
	int operation;
	xmlChar *Label_Name, *Label, *Property, *Tileset, *from, *to;
	int Appearance_Type, Gender, Phenotype;
} grl_element;


//internal gff_rules_list
typedef struct {
	int len;
	grl_element * list;
} gff_rules_list;


#define StringDataOffset sizeof(TLKHeader)
#define MAX_VALID_STRREF 0x00FFFFFF
#define ALT_TABLE        0x01000000

//String Flags
#define TEXT_PRESENT      0x0001
#define SND_PRESENT       0x0002
#define SNDLENGTH_PRESENT 0x0004

/* xmlrw .c */

//load command and talk tables from an XML file (or from stdin if fname == NULL)
void xmlread(const char * fname, int offset, DWORD lang, char sex, int quiet);

//write the talk table to an XML file (or to stdout if fname == NULL)
void xmlwrite(const char * fname, DWORD from, DWORD to);


/* tlkrw.c */

//load the talk table from a TLK file
void tlkread(const char * fname, int offset, char sex, int quiet);

//write the talk table to a TLK file
void tlkwrite(const char * fname, DWORD lang, char sex);


/* gff.c */

//parse a single GFF file
//return the new offset
int gffprocess(const char * fname, int offset, int extract, const gff_rules_list * list);

//add a rule to a gff_rules_list
gff_rules_list * gff_rules_list_add(gff_rules_list * list, xmlNode * rule);

//free a gff_rules_list
void gff_rules_list_free(gff_rules_list * list);



/* functions.c */

//return if the current OS is using BigEndian or LittleEndian
int IsBigEndian();

//convert LittleEndian <-> BigEndian
DWORD SwapEndian(DWORD x);

//add or update entry in the database
//data must be allocated with malloc and NOT free'd or overwritten thereafter
//if find_first_free is true, move from the given StrRef until a completely empty entry is found
//the allocated StrRef is returned.
DWORD db_insert(DWORD StrRef, DWORD lang, char sex, DWORD StringSize, const char * data, int quiet, int find_first_free);

//convert & to &amp; and ISO-8859 to UTF-8 and return the result in a statically allocated buffer
char * xml_encode(const char * string);

//convert a language string to a Bioware language ID
DWORD GetLangID(const char * slang);

//convert a string from the given encoding to UTF-8
char * charset_toUTF8 (const char * in, const char * encoding);

//convert a string from UTF-8 to the given encoding
char * charset_fromUTF8 (const char * in, const char * encoding);


/* global variables */

extern entry * db;
extern int BigEndian;

//this is NOT the number of strings present in the database, but the highest ResRef+1
extern DWORD StringCount;
