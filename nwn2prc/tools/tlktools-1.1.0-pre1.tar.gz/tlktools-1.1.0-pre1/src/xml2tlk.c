/*
 *  TLKTools - TLK<->XML generation tools
 *  xml2tlk.c
 *
 *  Copyright (C) 2004-2005 Guido Imperiale
 *  This code is released under the terms of the GNU GPL.
 *  Please refer to tlktools.h for more info.
 */

#include "tlktools.h"


int main(int argc, char ** argv)
{
    // initialize libxml2 and check potential ABI mismatches between
	// the version it was compiled for and the actual shared library used.
    LIBXML_TEST_VERSION

	//initialize BigEndian <-> LittleEndian conversion
	BigEndian = IsBigEndian();
	if (BigEndian)
		fprintf(stderr, "WARNING: operations on a BigEndian systems are totally UNTESTED.\n");

	if (argc < 3) {
		fprintf(stderr, "Usage: xml2tlk infile.xml outfile.tlk [langcode] [m|f]\n");
		exit(1);
	}

	DWORD lang;
	if (argc > 3)
		lang = GetLangID(argv[3]);
	else
		lang = 0;

	char sex;
	if (argc > 4)
		sex = argv[4][0];
	else
		sex = 'm';

	xmlread (argv[1], 0, 0, 'm', 0);
	tlkwrite(argv[2], lang, sex);

    xmlCleanupParser();
    xmlMemoryDump();

	return 0;
}
