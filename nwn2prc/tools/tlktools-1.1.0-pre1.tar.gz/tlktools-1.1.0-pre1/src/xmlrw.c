/*
 *  TLKTools - TLK<->XML generation tools
 *  xmlrw.c
 *
 *  Copyright (C) 2004-2005 Guido Imperiale
 *  This code is released under the terms of the GNU GPL.
 *  Please refer to tlktools.h for more info.
 */

#include "tlktools.h"


//test the name of the current node
int node_test(const xmlNode * node, const xmlChar * compar, int in_gff)
{
	assert(compar);
	if (node == NULL)
		return 0;
			
	in_gff -= (node->parent != NULL 
		&& node->parent->type == XML_ELEMENT_NODE 
		&& node->parent->name != NULL
		&& strcasecmp(node->parent->name, "gff") == 0);

	int ret = (in_gff == 0 
		&& node->type == XML_ELEMENT_NODE 
		&& node->name != NULL 
		&& strcasecmp(node->name, compar) == 0);
		
	//fprintf(stderr, "node_test(%s, %s, %d): %d\n", node->name, compar, in_gff, ret);
	return ret;
}


int xml_get_attr(xmlNode * node, const xmlChar * attr_name, int previous, int (*ret_fn)(const xmlChar * new, int previous))
{
	assert(node);
	assert(attr_name);
	
	xmlChar * sattr = xmlGetProp(node, attr_name);
	//fprintf(stderr, "xml_get_attr(%s, %s, %d): ", (sattr == NULL ? "NULL" : sattr), attr_name, previous);

	if (sattr != NULL) {
		previous = (*ret_fn)(sattr, previous);
		xmlFree(sattr);
	}
	
	//fprintf(stderr, "%d\n", previous);
	return previous;
}	


int __get_offset(const xmlChar * new, int previous)
{return previous + atol(new);}

int __get_id(const xmlChar * sID, int previous) {
	if (tolower(sID[0] == 'd'))
		return atoi(sID+1);
	else
		return 0x01000000 + atoi(sID);
}

int __get_lang(const xmlChar * new, int previous)
{return	(int)GetLangID(new);}

int __get_sex(const xmlChar * new, int previous) {
	int nsex = tolower(new[0]);
	if (nsex != 'm' && nsex != 'f') {
		fprintf(stderr, "ERROR: unknown sex: %c\n", nsex);
		exit(1);
	}
	return nsex;
}

int __get_generic(const xmlChar * new, int previous)
{return	atoi(new);}


void xmlparse(
	xmlNode * a_node, 
	int offset, 
	DWORD lang, 
	char sex, 
	int quiet, 
	int extract, 
	gff_rules_list * rules_list)
{
    xmlNode * cur_node = NULL;

	//new values
	int noffset;
 	DWORD nlang;
	char nsex;
	int nquiet;
	int nextract;

    for (cur_node = a_node; cur_node != NULL; cur_node = cur_node->next)
	{
		//acquire attributes
		noffset   =        xml_get_attr(cur_node, "offset" , offset   , __get_offset );
		nlang     = (DWORD)xml_get_attr(cur_node, "lang"   , (int)lang, __get_lang   );
		nsex      =  (char)xml_get_attr(cur_node, "sex"    , sex      , __get_sex    );
		nquiet    =        xml_get_attr(cur_node, "quiet"  , quiet    , __get_generic);
		nextract  =        xml_get_attr(cur_node, "extract", extract  , __get_generic);

		//evaluate entries without value
		if (node_test(cur_node, "find"   , 1)
		 || node_test(cur_node, "replace", 1)
		 || node_test(cur_node, "swap"   , 1)
		 || node_test(cur_node, "ftlk"   , 1)
		 || node_test(cur_node, "rtlk"   , 1) 
		 || node_test(cur_node, "stlk"   , 1))
		{
			rules_list = gff_rules_list_add(rules_list, cur_node);
		}
	
		//evaluate entries with value
        else if (cur_node->type == XML_TEXT_NODE && cur_node->parent != NULL) 
		{

			if (node_test(cur_node->parent, "entry", 0)) {
				DWORD id = (DWORD)xml_get_attr(cur_node->parent, "id", 0, __get_id);

				//create a copy of the string
				char * new_str = charset_fromUTF8(cur_node->content, "ISO-8859-1");
				int strsize = strlen(new_str);

				//fprintf(stderr, "entry(%u, \"%s\")\n", id + noffset, new_str);
				db_insert(id + noffset, nlang, nsex, strsize, new_str, nquiet, 0);
			}
			else if (node_test(cur_node->parent, "xmlread", 0)) {
				xmlread(cur_node->content, noffset, nlang, nsex, nquiet);
			}
			else if (node_test(cur_node->parent, "xmlwrite", 0)) {
				int from = xml_get_attr(cur_node->parent, "from", 0         , __get_id);
				int to   = xml_get_attr(cur_node->parent, "to"  , 0x01FFFFFF, __get_id);
				xmlwrite(cur_node->content, (DWORD)from & 0x00FFFFFF, (DWORD)to & 0x00FFFFFF);
			}
			else if (node_test(cur_node->parent, "tlkread", 0)) {
				tlkread(cur_node->content, noffset, nsex, nquiet);
			}
			else if (node_test(cur_node->parent, "tlkwrite", 0)) {
				tlkwrite(cur_node->content, nlang, nsex);
			}
			else if (node_test(cur_node->parent, "parse", 1)) {
				gffprocess(cur_node->content, noffset, nextract, rules_list);
			}
			else if (node_test(cur_node->parent, "parse_list", 1)) {
				FILE * lfp = fopen(cur_node->content, "rt");
				if (lfp == NULL) {
					fprintf(stderr, "Unable to parse list: %s\n", cur_node->content);
					exit(1);
				}
				
				char * buf = malloc(65536);
				assert(buf);
				int tmp_offset = noffset;
				while (fread(buf, 65536, 1, lfp)) 
				{
					//trim trailing newlines
					int bufend = strlen(buf) - 1;
					while (bufend >= 0 && (buf[bufend] == '\n' || buf[bufend] == '\r'))
						buf[bufend--] = '\0';
						
					if (bufend >= 0)
						tmp_offset = gffprocess(buf, tmp_offset, nextract, rules_list);
				}
					
				free(buf);
				fclose(lfp);
			}

		}

        xmlparse(cur_node->children, noffset, nlang, nsex, nquiet, nextract, rules_list);

		//if we're closing a <gff>, erase rules_list
		if (node_test(cur_node, "gff", 0)) {
			gff_rules_list_free(rules_list);
			rules_list = NULL;
		}

    }
	
}



void xmlread(const char * fname, int offset, DWORD lang, char sex, int quiet)
{
    xmlDocPtr doc = NULL;
	xmlNodePtr root_element = NULL;

	if (fname == NULL)
		fname = "-";

	doc = xmlReadFile(fname, NULL, 0);

    if (doc == NULL) {
        printf("ERROR: could not parse file %s\n", fname);
		return;
    }

    /*Get the root element node */
    root_element = xmlDocGetRootElement(doc);

    xmlparse(root_element, offset, lang, sex, quiet, 0, NULL);

    /*free the document */
    xmlFreeDoc(doc);

}


void xmlwrite(const char * fname, DWORD from, DWORD to)
{
	//fprintf(stderr, "xmlwrite(%s,%u,%u)\n", fname, from, to);

	entry * dbp;
	char parambuf[64];
	xmlDocPtr doc = NULL;       /* document pointer */
    xmlNodePtr root_node = NULL, node = NULL;	/* node pointers */

	//create root node
	doc = xmlNewDoc("1.0");
    root_node = xmlNewNode(NULL, "tlk");
    xmlDocSetRootElement(doc, root_node);
    xmlCreateIntSubset(doc, "tlk", NULL, "tlk2xml.dtd");

	for (dbp = db; dbp != NULL; dbp = dbp->right) 
	{
		if (dbp->StrRef < from)
			continue;
		if (dbp->StrRef > to)
			break;
	
		int lang;
		for (lang = 0; lang < 10; lang++) {

			char * langname = NULL;
			switch(lang) {
				case 0: langname = "en"; break;
				case 1: langname = "fr"; break;
				case 2: langname = "de"; break;
				case 3: langname = "it"; break;
				case 4: langname = "sp"; break;
				case 5: langname = "po"; break;
				case 6: langname = "ko"; break;
				case 7: langname = "ct"; break;
				case 8: langname = "cs"; break;
				case 9: langname = "jp"; break;
				default:
					break;
			}

			if (dbp->m[lang].data != NULL) {
			    node = xmlNewChild(root_node, NULL, "entry", xml_encode(dbp->m[lang].data));

				sprintf(parambuf, "%u", (unsigned int)dbp->StrRef);
    			xmlNewProp(node, "id", parambuf);
    			xmlNewProp(node, "lang", langname);
    			xmlNewProp(node, "sex", "m");
			}

			if (dbp->f[lang].data != NULL && (dbp->m[lang].data == NULL || strcmp(dbp->f[lang].data, dbp->m[lang].data) != 0)) {
			    node = xmlNewChild(root_node, NULL, "entry", xml_encode(dbp->f[lang].data));

				sprintf(parambuf, "%u", (unsigned int)dbp->StrRef);
    			xmlNewProp(node, "id", parambuf);
    			xmlNewProp(node, "lang", langname);
    			xmlNewProp(node, "sex", "f");
			}
		}
	}

	xmlSaveFormatFileEnc(fname == NULL ? "-" : fname, doc, "ISO-8859-1", 1);
    xmlFreeDoc(doc);
}
