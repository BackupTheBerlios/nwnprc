/* config.h.  Generated automatically by configure.  */
/* #undef HAVE_LIBPAM */
/* #undef HAVE_LIBCRYPTO */
