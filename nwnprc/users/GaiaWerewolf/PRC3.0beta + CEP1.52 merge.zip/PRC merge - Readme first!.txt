PRC/CEP MERGE HAK (alpha)
-----------------

1. Introduction
2. How to use
3. Credits/Contact details


++++++++++++++  1. Introduction  ++++++++++++++++++++++

This is the official PRC/CEP merge hak. What this does is let users use both the
Community Expansion Pack (CEP) and our PRC pack together with hopefully very few
(if any) conflict between files.

While we're 99% sure it will absolutely, definitely work, bear in mind you are
using this at your own risk. We cannot guarantee the CEP plays nice with the
our hakpaks.

The versions this merge hak is supposed to work with are

- PRC 3.0 beta 1
- CEP 1.52

NOTE: CEP custom races are not in this hak. This is because apart from the fact
      that there were only two in the first place, some updates broke them
      anyhow. You shouldn't be using the CEP races, they just don't work now.

The upcoming version 3.0 of the PRC and the upcoming update to the CEP will play
much nicer together.


++++++++++++++  2. How to use  ++++++++++++++++++++++++

 - Open the file you've downloaded with something like WinZIP or WinRAR.

 - Extract the files to the place on your computer where you installed NWN.
   For example, "C:\Games\NWN\" (it might be different for you). The files should
   now be installed in the right place.

 - Open the module you are going to use/using the CEP and PRC with, in the toolset.

 - Go to the "Edit" menu and click "Module Properties"

 - Click on the "Custom Content" tab.

 - In the first dropdown list, find the entry named "prc3b1+cep152" and click Add.
   Move it to the top of the list.

 - In the second dropdown list, Custom Tlk File, find the entry called
   "prc_consortium"

 - Click OK to save changes. Done!


          -->> Make sure that the merge hak stays above <<--
          -->> the PRC and the CEP content on the list! <<--

(Please follow the instructions before asking for help)



++++++++++++++  3. Credits/Contact details  ++++++++++++

Merge hak author: Gaia_Werewolf

Main PRC website: http://nwn-prc.com/ or http://nwnprc.netgamers.co.uk/
