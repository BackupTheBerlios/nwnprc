PRC/CEP MERGE HAK (alpha)
-----------------

1. Introduction
2. How to use
3. Credits/Contact details


++++++++++++++  1. Introduction  ++++++++++++++++++++++

This is the official PRC/CEP merge hak. What this does is let users use both the
Community Expansion Pack (CEP) and our PRC pack together with hopefully very few
(if any) conflict between files.

While we're 99% sure it will absolutely, definitely work, bear in mind you are
using this at your own risk. We cannot guarantee the CEP plays nice with the
our hakpaks.

The versions this merge hak is supposed to work with are

- PRC 3.0 beta 3
- CEP 1.52

NOTE: CEP custom races are not in this hak. This is because apart from the fact
      that there were only two in the first place, some updates broke them
      anyhow. You shouldn't be using the CEP races, they just don't work now.

The upcoming version 3.0 of the PRC and the upcoming update to the CEP will play
much nicer together.

NOTE: I know that there have been problems when people tried to add this hakpak,
      and I am currently trying to resolve them. It will probably work better when
      patch 1.67 is out.


++++++++++++++  2. How to use  ++++++++++++++++++++++++

Unfortunately, there have been problems in the past with some people adding this to
their module. Therefore, until patch 1.67 comes out, I cannot and will not put in any
instructions on how to use this. The new patch will fix it.

If you do not know how to add hakpaks and talk tables to your module, do not ask me
how to use this. It may not work, it may only give you problems and I don't have the
time to get things to work when there are issues with the toolset I can't fix.


[This is not meant to sound rude, but I really can't help it for now.]


++++++++++++++  3. Credits/Contact details  ++++++++++++

Merge hak author: Gaia_Werewolf

Main PRC website: http://nwn-prc.com/ or http://nwnprc.netgamers.co.uk/
